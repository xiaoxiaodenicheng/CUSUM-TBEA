%integrand = @(z)(z.*pdfZ(8, 5, z, 1, 10, 1, 4, 10, 1, 0.8, 10, 10));
integrand = @(z)(z.*pdfZ(8, 5, z, 4, 4946, 1165.43, 1, 58.9, 17.28, 0.4657, 4946,58.9 ));

Ez = integral(integrand, eps, 10);
fprintf('Ez = %.5f\n', Ez);
% （改分布类型改第4个值和第7个值；改相关性改倒数第3个值；改统计量改第二个值）
% C = 8;            % Copula类型: 
                    % 8=Clayton ;  9=franck ; 10=gumbel

% ZZ = 7;           % 联合监控统计量Z的计算方式:
                    % 5: Z = X1 - T1 ;  6: Z = X1 ./ T1 ;  7:Z = X1 + (1 ./ T1)
                    
% UCL = 1.5;        % 需要计算的 PDF 位置


% disX = 1;         % X 的分布类型
                    % 1=Gamma  2=Lognormal  3=Normal  4=Weibull分布
% muX0 = 10;        % X 的均值
% sdX0 = 1;         % X 的标准差

% disT = 1;         % T 的分布类型
% muT0 = 10;        % T 的均值
% sdT0 = 1;         % T 的标准差

% tau = 0.2;        % 相关性参数
% muX1 = 10;        % 变换参数
% muT1 = 10;        % 变换参数