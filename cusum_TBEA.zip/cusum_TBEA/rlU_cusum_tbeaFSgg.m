function ARL = rlU_cusum_tbeaFSgg(K, UCLc, rho1, rho2, muX0, muT0)

    % 分布参数：  X：gamma分布  T：gamma分布
    mu0 = 10;
    sigma0 = 1;
    sigma1 = 1;
    muX1 = rho1 * muX0;
    muT1 = rho2 * muT0;
    aX1 = (muX1 / sigma0)^2;
    bX1 = muX1 / aX1;
    aT1 = (muT1 / sigma1)^2;
    bT1 = muT1 / aT1;

    % cusum结构参数：
    C0=0;
    %G-G 0.2时
    EZ=0.0470;
    %EZ=1.0073;
    %EZ=2.0099;
    
    %G-G 0.5时
    %EZ=0.0317;
    %EZ=1.0034;
    %EZ=2.0101;

    %G-G 0.8时
    %EZ=0.0146;
    %EZ=1.0008;
    %EZ=2.0101;

    % Frank Copula 的相关性参数
    tau = 0.2; % 根据需要调整 Kendall's tau 值
    theta = francktheta(tau); % 计算 Frank Copula 的参数

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

    % 设置蒙特卡洛仿真次数
    rep = 3;
    RL = zeros(rep, 1);
    for i = 1:rep

        % 生成相关的随机变量 X1 和 T1 使用 Frank Copula
        [u, v] = frank_copula_samples(theta, 1);
        X1 = gaminv(u, aX1, bX1) / mu0;
        T1 = gaminv(v, aT1, bT1) / mu0;

        % 计算 X 和 Z
        
        x = X1 - T1;
        %x = X1/T1;
        %x = X1 + 1 / T1;
        C = max(0,C0+(x-EZ)-K);
        j=1;
        
        while j>=1 
            if C > UCLc
               RL(i) = j;
               break;
            else
                %[u, v] = clayton_copula_samples(theta, 1);
                [u, v] = frank_copula_samples(theta, 1);
                X1 = gaminv(u, aX1, bX1) / mu0;
                T1 = gaminv(v, aT1, bT1) / mu0;
                x = X1 - T1;
                %x = X1/T1;
                %x = X1 + 1 / T1;
                C = max(0,C+(x-EZ)-K);
                j=j+1;
                disp(X1);
                disp(T1);
                disp(x);

            end
        end
    end

    % 计算结果
    ARL = mean(RL);

    % 输出结果
    fprintf('ARL: %.4f\n', ARL);
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% 辅助函数：生成 Frank Copula 样本
function [u, v] = frank_copula_samples(theta, n)
    % Frank Copula 的生成公式
    % theta 是 Copula 参数
    % n 是样本数量
    
    u = rand(n, 1);
    w = rand(n, 1);
    
    % 计算 Frank Copula 的相关样本
    v = -(1/theta) .* log(1 + (w .* (1 - exp(-theta))) ./ (w .* (exp(-theta .* u) - 1) - exp(-theta .* u)));
end


% z0=0;
% rep=100000;
% RL=zeros(rep,1);
% for i=1:rep
%     x=exprnd(beta1);
%     z=max(0,z0+(x-1)-K);
%     %z=max(mu0,x-(mu0+K)+z0);
%     j=1;
%     while j>=1
%         if z>UCLc||x>UCLs
%             RL(i)=j;
%             break
%         else
%            x=exprnd(beta1);
%            z=max(0,z+(x-1)-K);
%            %z=max(mu0,x-(mu0+K)+z);
%            j=j+1;
%         end
%      end
% end
% ARL=mean(RL);
