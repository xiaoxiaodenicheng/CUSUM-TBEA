function ARL = rlU_cusum_tbeaCSgw(K, UCLc, rho1, rho2, muX0, muT0)
 
    % 参数设置
    mu0 = 10;
    sigma0 = 1;
    sigma1 = 1;
    muX1 = rho1 * muX0;
    muT1 = rho2 * muT0;
    aX1 = (muX1 / sigma0)^2;
    bX1 = muX1 / aX1;
    options = optimset('Display', 'off');
    aT1 = fsolve(@(aT1) abfrommusdW_T(aT1, muT1, sigma1), 2, options);
    bT1 = muT1 / gamma(1 / aT1 + 1);
    function z = abfrommusdW_T(aT1, muT1, sigma1)
        if aT1 <= 0, z = 1e4;
            else, z = muT1^2 * (gamma(2 / aT1 + 1) / gamma(1 / aT1 + 1)^2 - 1) - sigma1^2;
        end
    end

    % cusum结构参数：
    C0=0;
    %G-W 0.2时
    %EZ=0.04592;
    %EZ=1.00729;
    %EZ=2.01121;
    
    %G-W 0.5时
    EZ=0.02999;
    %EZ=1.00329;
    %EZ=2.01130;

    %G-W 0.8时
    %EZ=0.01495;
    %EZ=1.00107;
    %EZ=2.01120;

    %G-W realdata
    %EZ = 0.08082;
    %EZ = 1.03278;
    %EZ = 2.08818;

    % Clayton Copula 的相关性参数
    tau = 0.5; % 根据需要调整 Kendall's tau 值
    %tau = 0.4665;
    theta = claytontheta(tau); % 计算 Clayton Copula 的参数

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

    % 设置蒙特卡洛仿真次数
    rep = 100;
    RL = zeros(rep, 1);
    for i = 1:rep
       
        % 使用 Clayton Copula生成相关的随机变量 X1 和 T1 
        % gaminv() 是 MATLAB 自带的函数，用于计算 Gamma 分布的逆累积分布函数（Inverse CDF, Percentile Function）
        [u, v] = clayton_copula_samples(theta, 1);
        %X1 = gaminv(u, aX1, bX1) / mu0;
        %X1 = norminv(u, aX1, bX1) / mu0;
        
        X1 = gaminv(v, aX1, bX1) / mu0;
        T1 = wblinv(u, bT1, aT1) / mu0;

        % 计算 X 和 Z
        x = X1 - T1;
        %x = X1/T1;
        %x = X1 + 1 / T1;
        C = max(0,C0+(x-EZ)-K);
        j=1;

        while j>=1 
            if C > UCLc
               RL(i) = j;
               break;
            else
                [u, v] = clayton_copula_samples(theta, 1);
                %X1 = gaminv(u, aX1, bX1) / mu0;
                %X1 = norminv(u, aX1, bX1) / mu0;
                X1 = gaminv(v, aX1, bX1) / mu0;
                T1 = wblinv(u, bT1, aT1) / mu0;
                x = X1 - T1;
                %x = X1/T1;
                %x = X1 + 1 / T1;
                C = max(0,C+(x-EZ)-K);
                fprintf('rep=%d, j=%d, C=%.4f\n', i, j, C);  % ← 输出C的变化
                j=j+1;
            end
        end
    end

    % 计算结果
    ARL = mean(RL);

    % 输出结果
    fprintf('ARL: %.4f\n', ARL);
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% 辅助函数：生成 Clayton Copula 样本
function [u, v] = clayton_copula_samples(theta, n)
    % 生成 n 个独立均匀样本
    u = rand(n, 1);
    w = rand(n, 1);
    
    % 使用 Clayton Copula 的公式生成相关样本
    v = (u.^(-theta) .* (w.^(-theta / (1 + theta)) - 1) + 1).^(-1 / theta);
end
