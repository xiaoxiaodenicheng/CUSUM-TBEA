function ARL = rlU_cusum_tbeaFSwg(K, UCLc, rho1, rho2, muX0, muT0)

    % 分布参数：  X：weibull分布  T：gamma分布
    %mu0 = 10;
    %mu1 = 10;
    %sigma0 = 1;
    %sigma1 = 1;

    mu0 = 4946;
    mu1 = 58.9;
    sigma0 = 1165.43;
   % sigma1 = 17.28;
    sigma1 = 17.26;

    muX1 = rho1 * muX0;
    muT1 = rho2 * muT0;
    options = optimset('Display', 'off');
    aX1 = fsolve(@(aX1) abfrommusdW_X(aX1, muX1, sigma0), 2, options);
    bX1 = muX1 / gamma(1 / aX1 + 1);
    function z = abfrommusdW_X(aX1, muX1, sigma0)
        if aX1 <= 0, z = 1e4;
            else, z = muX1^2 * (gamma(2 / aX1 + 1) / gamma(1 / aX1 + 1)^2 - 1) - sigma0^2;
        end
    end
    aT1 = (muT1 / sigma1)^2;
    bT1 = muT1 / aT1;

    % cusum结构参数：
    C0=0;
    %W-G 0.2时
    %EZ=0.04702;
    %EZ=1.00742;
    %EZ=2.01005;
    
    %W-G 0.5时
    %EZ=0.03211;
    %EZ=1.00339;
    %EZ=2.01018;

    %W-G 0.8时
    %EZ=0.01605;
    %EZ=1.00094;
    %EZ=2.01009;

    %W-G realdata
    %EZ = 0.09100;
    %EZ = 1.04522;
    EZ = 2.09410;

    % Clayton Copula 的相关性参数
    %tau = 0.5; % 根据需要调整 Kendall's tau 值
    %theta = claytontheta(tau); % 计算 Clayton Copula 的参数
    
    % Frank Copula 的相关性参数
    %tau = 0.8; % 根据需要调整 Kendall's tau 值

    tau = 0.4657;
    theta = francktheta(tau); % 计算 Frank Copula 的参数
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

    % 设置蒙特卡洛仿真次数
    rep = 100000;
    RL = zeros(rep, 1);
    for i = 1:rep
       
        % 使用 Clayton Copula生成相关的随机变量 X1 和 T1 
        % gaminv() 是 MATLAB 自带的函数，用于计算 Gamma 分布的逆累积分布函数（Inverse CDF, Percentile Function）
        %[u, v] = clayton_copula_samples(theta, 1);

        % 生成相关的随机变量 X1 和 T1 使用 Frank Copula
        [u, v] = frank_copula_samples(theta, 1);
        %X1 = gaminv(u, aX1, bX1) / mu0;
        %X1 = norminv(u, aX1, bX1) / mu0;
        X1 = wblinv(u, bX1, aX1) / mu0;
        T1 = gaminv(v, aT1, bT1) / mu1;

        % 计算 X 和 Z
        %x = X1 - T1;
        %x = X1/T1;
        x = X1 + 1 / T1;
        C = max(0,C0+(x-EZ)-K);
        j=1;

        while j>=1 
            if C > UCLc
               RL(i) = j;
               break;
            else
                %[u, v] = clayton_copula_samples(theta, 1);
                %X1 = gaminv(u, aX1, bX1) / mu0;
                %X1 = norminv(u, aX1, bX1) / mu0;

                % 生成相关的随机变量 X1 和 T1 使用 Frank Copula
                [u, v] = frank_copula_samples(theta, 1);
                X1 = wblinv(u, bX1, aX1) / mu0;
                T1 = gaminv(v, aT1, bT1) / mu1;

                %x = X1 - T1;
                %x = X1/T1;
                x = X1 + 1 / T1;

                C = max(0,C+(x-EZ)-K);
                j=j+1;
            end
        end
    end

    % 计算结果
    ARL = mean(RL);

    % 输出结果
    fprintf('ARL: %.4f\n', ARL);
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% 辅助函数：生成 Frank Copula 样本
function [u, v] = frank_copula_samples(theta, n)
    % Frank Copula 的生成公式
    % theta 是 Copula 参数
    % n 是样本数量
    
    u = rand(n, 1);
    w = rand(n, 1);
    
    % 计算 Frank Copula 的相关样本
    v = -(1/theta) .* log(1 + (w .* (1 - exp(-theta))) ./ (w .* (exp(-theta .* u) - 1) - exp(-theta .* u)));
end




