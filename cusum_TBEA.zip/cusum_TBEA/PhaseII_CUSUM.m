
% ============================================
% 从 Excel 读取数据并绘制 SCI 风格的单侧 CUSUM 控制图
% 图形风格参考 Fig2_Shewhart_TBEA_PhaseI_Z1.svg
% ============================================

clc;
clear;
close all;

%% 1. 从 Excel 读取数据
filename = 'REALDATA.xlsx';
data = readmatrix(filename);

% 转换为列向量，并去除缺失值
data = data(:);
data = data(~isnan(data));
n = length(data);

if n < 2
    error('数据量太少，请至少提供两个有效观测值。');
end

%% 2. 参数设置
 %mu0 = 0.08082;
 mu0 = 1.03278;   % 估计初始均值
%mu0 = 2.08818;

k = 0.15;
%   k=0.15 时的控制限:H = 0.40235 / 1.20480 / 1.31126
H = 1.20480;

%% 3. 计算单侧 CUSUM 统计量
% 仅检测过程均值上升
S = zeros(n, 1);

for i = 2:n
    S(i) = max(0, S(i-1) + data(i) - mu0 - k);
end

%% 4. SCI 论文风格参数设置
% 配色
blue = [0.00, 0.40, 0.85];    % 蓝色数据线
red  = [1.00, 0.20, 0.20];    % 红色控制限
axisColor = [0.25, 0.25, 0.25];

% 字体
fontName = 'Times New Roman';
fontSize = 10;

% 线宽
dataLineWidth = 1.1;
controlLineWidth = 1.1;
axisLineWidth = 0.8;
markerSize = 4.5;

%% 5. 创建图形
figure('Name', 'CUSUM Control Chart', ...
       'NumberTitle', 'off', ...
       'Color', 'white', ...
       'Units', 'centimeters', ...
       'Position', [5, 5, 12.5, 8.5]);

ax = axes;
hold(ax, 'on');
box(ax, 'off');

% 数据序列：蓝色细线 + 空心圆
plot(1:n, S, '-o', ...
    'Color', blue, ...
    'LineWidth', dataLineWidth, ...
    'Marker', 'o', ...
    'MarkerSize', markerSize, ...
    'MarkerEdgeColor', blue, ...
    'MarkerFaceColor', 'white');

%% 6. 绘制上控制限
yline(H, '--', ...
    'Color', red, ...
    'LineWidth', controlLineWidth, ...
    'HandleVisibility', 'off');

%% 7. 坐标轴设置
% 横坐标范围：根据样本量自动调整
xlim([0, n + 1]);

% 横坐标刻度：以 5 为间隔
if n <= 15
    xticks(0:1:n);
else
    xticks(0:5:ceil(n/5)*5);
end

% 纵坐标上限：同时考虑统计量最大值和控制限
yMaxData = max([S; H]);
if yMaxData <= 0
    yUpper = 1;
else
    yUpper = 0.1 * ceil(1.15 * yMaxData / 0.1);
end

ylim([0, yUpper]);

% 根据纵坐标范围自动设置刻度间隔
if yUpper <= 1
    yStep = 0.5;
elseif yUpper <= 2
    yStep = 0.05;
else
    yStep = 0.5;
end

yticks(0:yStep:yUpper);

% 坐标轴外观
set(ax, ...
    'FontName', fontName, ...
    'FontSize', fontSize, ...
    'FontWeight', 'normal', ...
    'LineWidth', axisLineWidth, ...
    'XColor', axisColor, ...
    'YColor', axisColor, ...
    'TickDir', 'out', ...
    'TickLength', [0.015, 0.015], ...
    'XMinorTick', 'off', ...
    'YMinorTick', 'off', ...
    'Layer', 'top');

% 不显示网格
grid(ax, 'off');

%% 8. 坐标轴标签：数学公式格式
xlabel('$t$', ...
    'Interpreter', 'latex', ...
    'FontName', fontName, ...
    'FontSize', 11);

ylabel('$C_t^+$', ...
    'Interpreter', 'latex', ...
    'FontName', fontName, ...
    'FontSize', 11);

%% 9. 在控制限右侧标注数值
% 标签放在控制限稍上方，避免与虚线重叠
text(n + 0.8, H + 0.035 * yUpper, ...
    sprintf('$UCL_2 = %.5f$', H), ...
    'Interpreter', 'latex', ...
    'FontName', fontName, ...
    'FontSize', 9, ...
    'HorizontalAlignment', 'right', ...
    'VerticalAlignment', 'bottom', ...
    'Color', [0.15, 0.15, 0.15], ...
    'Clipping', 'off');

%% 10. 标记超出控制限的观测点
% 保留空心圆风格，不额外改变数据点颜色
out_of_control = find(S > H);

if ~isempty(out_of_control)
    plot(out_of_control, S(out_of_control), 'o', ...
        'MarkerSize', markerSize + 0.5, ...
        'MarkerEdgeColor', red, ...
        'MarkerFaceColor', 'white', ...
        'LineWidth', 1.1, ...
        'HandleVisibility', 'off');
end

%% 13. 导出 SVG 矢量图
exportgraphics(gcf, 'CUSUM_Control_Chart2.svg', ...
    'ContentType', 'vector');

disp('SVG 矢量图已成功导出。');
%% 12. 可选：导出高分辨率图片
% exportgraphics(gcf, 'CUSUM_Control_Chart.png', ...
%     'Resolution', 600);

% 可选：导出矢量图，适合 SCI 论文
% exportgraphics(gcf, 'CUSUM_Control_Chart.pdf', ...
%     'ContentType', 'vector');
