
% ============================================
% 从 Excel 读取数据并绘制 SCI 风格的 Shewhart 控制图
% 图形风格与 CUSUM_Control_Chart2.svg 保持一致
% ============================================

clc;
clear;
close all;

%% 1. 从 Excel 读取数据
filename = 'REALDATA.xlsx';
data = readmatrix(filename);

% 转换为列向量，并去除缺失值
data = data(:);
data = data(~isnan(data));
n = length(data);

if n < 2
    error('数据量太少，请至少提供两个有效观测值。');
end

%% 2. 参数设置

% mu0 = 0.08082;
% mu0 = 1.03278;   % 估计初始均值
 mu0 = 2.08818;

%UCL = 0.59336;     % 上控制限
%UCL = 2.1300;
UCL = 3.26562;

% 如果后续需要下控制限，可取消注释并设置相应数值
% LCL = ...;

CL = mu0;

%% 3. SCI 论文风格参数设置
% 与 CUSUM 控制图保持一致
blue = [0.00, 0.40, 0.85];     % 蓝色数据线
red = [1.00, 0.20, 0.20];      % 红色控制限
axisColor = [0.25, 0.25, 0.25];

% 字体
fontName = 'Times New Roman';
fontSize = 10;

% 线宽与标记尺寸
dataLineWidth = 1.1;
controlLineWidth = 1.1;
axisLineWidth = 0.8;
markerSize = 4.5;

%% 4. 创建图形
figure('Name', 'Shewhart Control Chart', ...
       'NumberTitle', 'off', ...
       'Color', 'white', ...
       'Units', 'centimeters', ...
       'Position', [5, 5, 12.5, 8.5]);

ax = axes;
hold(ax, 'on');
box(ax, 'off');

% 数据序列：蓝色细线 + 空心圆
plot(1:n, data, '-o', ...
    'Color', blue, ...
    'LineWidth', dataLineWidth, ...
    'Marker', 'o', ...
    'MarkerSize', markerSize, ...
    'MarkerEdgeColor', blue, ...
    'MarkerFaceColor', 'white');

%% 5. 绘制上控制限
yline(UCL, '--', ...
    'Color', red, ...
    'LineWidth', controlLineWidth, ...
    'HandleVisibility', 'off');

%% 6. 绘制中心线
% 中心线采用灰色实线，与控制限区分
yline(CL, '-', ...
    'Color', [0.60, 0.60, 0.60], ...
    'LineWidth', 0.9, ...
    'HandleVisibility', 'off');

%% 7. 坐标轴设置
% 横坐标范围与 CUSUM 代码一致
xlim([0, n + 1]);

if n <= 15
    xticks(0:1:n);
else
    xticks(0:5:ceil(n/5)*5);
end

% 纵坐标范围：同时考虑数据、中心线和上控制限
yMinData = min([data; CL]);
yMaxData = max([data; CL; UCL]);

yRange = yMaxData - yMinData;

% 防止所有数值相同导致坐标范围为零
if yRange <= 0
    yRange = max(abs(yMaxData), 1);
end

yLower = yMinData - 0.10 * yRange;
yUpper = yMaxData + 0.10 * yRange;

ylim([yLower, yUpper]);

% 纵坐标刻度
% 纵坐标刻度：与 CUSUM 代码保持一致
if yUpper <= 1
    yStep = 0.2;
elseif yUpper <= 2
    yStep = 0.05;
else
    yStep = 0.2;
end

yticks(0:yStep:yUpper);
% 坐标轴外观：与 CUSUM 代码一致
set(ax, ...
    'FontName', fontName, ...
    'FontSize', fontSize, ...
    'FontWeight', 'normal', ...
    'LineWidth', axisLineWidth, ...
    'XColor', axisColor, ...
    'YColor', axisColor, ...
    'TickDir', 'out', ...
    'TickLength', [0.015, 0.015], ...
    'XMinorTick', 'off', ...
    'YMinorTick', 'off', ...
    'Layer', 'top');

% 不显示网格
grid(ax, 'off');

%% 8. 坐标轴标签
xlabel('$t$', ...
    'Interpreter', 'latex', ...
    'FontName', fontName, ...
    'FontSize', 11);

ylabel('$Z_t$', ...
    'Interpreter', 'latex', ...
    'FontName', fontName, ...
    'FontSize', 11);

%% 9. 标注控制限和中心线
% 标签放在图形右侧
text(n + 0.8, UCL + 0.025 * (yUpper - yLower), ...
    sprintf('$UCL_3 = %.5f$', UCL), ...
    'Interpreter', 'latex', ...
    'FontName', fontName, ...
    'FontSize', 9, ...
    'HorizontalAlignment', 'right', ...
    'VerticalAlignment', 'bottom', ...
    'Color', [0.15, 0.15, 0.15], ...
    'Clipping', 'off');

text(n + 0.8, CL, ...
    sprintf('$CL = %.5f$', CL), ...
    'Interpreter', 'latex', ...
    'FontName', fontName, ...
    'FontSize', 9, ...
    'HorizontalAlignment', 'right', ...
    'VerticalAlignment', 'bottom', ...
    'Color', [0.35, 0.35, 0.35], ...
    'Clipping', 'off');

%% 10. 标记超出控制限的观测点
% 当前仅检测超过上控制限的点
out_of_control = find(data > UCL);

if ~isempty(out_of_control)
    plot(out_of_control, data(out_of_control), 'o', ...
        'MarkerSize', markerSize + 0.5, ...
        'MarkerEdgeColor', red, ...
        'MarkerFaceColor', 'white', ...
        'LineWidth', 1.1, ...
        'HandleVisibility', 'off');
end

%% 11. 导出 SVG 矢量图
set(gcf, 'InvertHardcopy', 'off');

exportgraphics(gcf, 'Shewhart_Control_Chart3.svg', ...
    'ContentType', 'vector');

%% 12. 输出结果
fprintf('Shewhart 控制图已生成并导出为 SVG 矢量图。\n');
fprintf('样本量：%d\n', n);
fprintf('中心线 CL = %.5f\n', CL);
fprintf('上控制限 UCL = %.5f\n', UCL);
fprintf('超出上控制限的观测点数量：%d\n', ...
    numel(out_of_control));
