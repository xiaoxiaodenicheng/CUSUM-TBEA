function compute_table15()
%COMPUTE_TABLE15  Goodness-of-fit of the marginal distributions fitted to the
%   Phase I sample of Table 11 (manuscript Table 15).
%
%       T : Gamma, Weibull           (location parameter fixed at 0)
%       X : Gamma, Weibull, Normal   (Gamma/Weibull: loc = 0; Normal: MLE)
%
%   All estimates are maximum likelihood.  K-S, A-D and CvM are evaluated on
%   the fitted CDF;  AIC = 2k - 2*logL,  BIC = k*log(n) - 2*logL  with k = 2.
%
%   Only base MATLAB is used (no toolboxes): the gamma/Weibull/normal
%   pdf and cdf are written out explicitly and the MLE is obtained with
%   FMINSEARCH.  The table is printed and written to Table15_marginal_GOF.csv.
%
%   Reference values (Python/scipy, loc = 0 MLE):
%       T  Gamma   a = 11.1006, b =   5.3060 : KS .0932 AD .2754 CvM .0358
%       T  Weibull k =  3.8683, l =  65.1738 : KS .1289 AD .3257 CvM .0553
%       X  Gamma   a = 17.9873, b = 274.9715 : KS .1227 AD .4677 CvM .0725
%       X  Weibull k =  4.7753, l = 5400.141 : KS .1096 AD .3069 CvM .0370
%       X  Normal  mu = 4946.0, s = 1145.846 : KS .1224 AD .3509 CvM .0460

T = [62 79 58 33 85 92 69 67 43 41 55 78 56 53 41 81 32 70 82 51 ...
     57 47 51 24 58 62 45 58 52 85];
X = [4890 6180 3730 2930 7600 5580 4570 5230 4470 3420 3460 5360 ...
     4470 4470 3320 4910 5010 6630 5710 5130 5330 5010 3660 3340 ...
     3600 5560 5760 6440 6310 6300];
n = numel(T);

specs = {'Gamma','T'; 'Weibull','T'; 'Gamma','X'; 'Weibull','X'; 'Normal','X'};

fprintf('Table 15  Goodness-of-fit test of the marginal distributions ');
fprintf('fitted to the Phase I samples (n = %d)\n\n', n);
fprintf('%-4s %-8s %11s %11s %9s %9s %9s %10s %10s\n', ...
        'Var','Model','par1','par2','K-S','A-D','CvM','AIC','BIC');

fid = fopen('Table15_marginal_GOF.csv', 'w');
fprintf(fid, 'Variable,Model,par1,par2,KS,AD,CvM,AIC,BIC\n');

for i = 1:size(specs, 1)
    if strcmp(specs{i,2}, 'T'), data = T; else, data = X; end
    dist = specs{i,1};
    [par, logL] = fit_marginal(dist, data);
    D  = ks_stat(data, @(z) marg_cdf(dist, z, par));
    AD = ad_stat(data, @(z) marg_cdf(dist, z, par));
    W  = cvm_stat(data, @(z) marg_cdf(dist, z, par));
    aic = 4 - 2*logL;              % k = 2
    bic = 2*log(n) - 2*logL;
    fprintf('%-4s %-8s %11.4f %11.4f %9.4f %9.4f %9.4f %10.4f %10.4f\n', ...
            specs{i,2}, dist, par(1), par(2), D, AD, W, aic, bic);
    fprintf(fid, '%s,%s,%.6f,%.6f,%.6f,%.6f,%.6f,%.6f,%.6f\n', ...
            specs{i,2}, dist, par(1), par(2), D, AD, W, aic, bic);
end
fclose(fid);
fprintf('\nwritten: Table15_marginal_GOF.csv\n');
end

% ---------------------------------------------------------------------------
function [par, logL] = fit_marginal(dist, data)
m = mean(data); v = var(data); s = std(data);   % s uses n-1, start value only
opts = optimset('TolX', 1e-10, 'TolFun', 1e-12, ...
                'MaxFunEvals', 2e5, 'MaxIter', 2e5, 'Display', 'off');
switch lower(dist)          % case-insensitive: 'Gamma' / 'gamma' both work
    case 'gamma'
        f = @(p) nll_gamma(data, p);
        starts = [max(m^2/v, 0.1) v/m;  1 1;  5 m/5;  2 m/2;  20 m/20];
    case 'weibull'
        f = @(p) nll_weibull(data, p);
        starts = [1.2 m;  2 m;  3 m;  4 m;  5 1.2*m];
    case 'normal'
        f = @(p) nll_normal(data, p);
        starts = [m 0.98*s;  m s];
    otherwise
        error('compute_table15:fit_marginal', 'unknown distribution: %s', dist);
end
best = Inf; par = starts(1,:);
for i = 1:size(starts, 1)
    [p_i, f_i] = fminsearch(f, starts(i,:), opts);
    if f_i < best, best = f_i; par = p_i; end
end
logL = -best;
end

function f = nll_gamma(x, p)
if p(1) <= 0 || p(2) <= 0, f = 1e12; return; end
f = -sum((p(1)-1)*log(x) - x/p(2) - gammaln(p(1)) - p(1)*log(p(2)));
end

function f = nll_weibull(x, p)
if p(1) <= 0 || p(2) <= 0, f = 1e12; return; end
f = -sum(log(p(1)) - p(1)*log(p(2)) + (p(1)-1)*log(x) - (x/p(2)).^p(1));
end

function f = nll_normal(x, p)
if p(2) <= 0, f = 1e12; return; end
m = numel(x);
f = m/2*log(2*pi) + m*log(p(2)) + sum((x - p(1)).^2)/(2*p(2)^2);
end

function y = marg_cdf(dist, x, p)
switch lower(dist)          % case-insensitive
    case 'gamma',   y = gammainc(x/p(2), p(1));          % lower regularised
    case 'weibull', y = 1 - exp(-(x/p(2)).^p(1));
    case 'normal',  y = 0.5*erfc(-(x-p(1))./(p(2)*sqrt(2)));
    otherwise
        error('compute_table15:marg_cdf', 'unknown distribution: %s', dist);
end
end

function D = ks_stat(x, cdfh)
xs = sort(x(:)); m = numel(xs);
F = cdfh(xs);
D = max(max(F - (0:m-1)'/m), max((1:m)'/m - F));
end

function A = ad_stat(x, cdfh)
xs = sort(x(:)); m = numel(xs);
F = min(max(cdfh(xs), 1e-12), 1 - 1e-12);
i = (1:m)';
A = -m - sum((2*i - 1) .* (log(F) + log(1 - F(end:-1:1)))) / m;
end

function W = cvm_stat(x, cdfh)
xs = sort(x(:)); m = numel(xs);
F = cdfh(xs); i = (1:m)';
W = 1/(12*m) + sum((F - (2*i - 1)./(2*m)).^2);
end
