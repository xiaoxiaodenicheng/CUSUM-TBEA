function compute_table13_14()
%COMPUTE_TABLE13_14  Copula goodness-of-fit for the Frank and Clayton copulas
%   fitted to the Phase I sample of Table 11 (manuscript Tables 13 and 14).
%
%   Table 13: MLE of the dependence parameter on the PIT pseudo-observations
%             u = rank(T)/(n+1), v = rank(X)/(n+1);  logLik, AIC = 2 - 2*logL,
%             BIC = log(n) - 2*logL, the Rosenblatt Cramer-von Mises statistic
%             and its parametric-bootstrap p-value (NBOOT replicates, the
%             parameter is re-estimated at every replicate).
%   Table 14: lower-tail agreement,  lam(q) = C_n(q,q)/q  evaluated on the
%             pseudo-observations, and the simulation-based GOF p-value and
%             median of lam(q) under each fitted copula (NSIM replicates).
%
%   Only base MATLAB is used (no toolboxes).  NOTE: the bootstrap p-values
%   depend on the random number stream, so they reproduce the published
%   values up to Monte-Carlo error (~+-0.02); the point estimates, logLik,
%   AIC, BIC, CvM statistics, lam(q) and the medians are deterministic.
%
%   Reference values (Python/scipy):
%     Clayton th = 1.3687 logLik 7.2094 AIC -12.4188 BIC -11.0176 CvM .0504 p .9335
%     Frank   th = 4.7340 logLik 6.7802 AIC -11.5604 BIC -10.1592 CvM .0485 p .9450

T = [62 79 58 33 85 92 69 67 43 41 55 78 56 53 41 81 32 70 82 51 ...
     57 47 51 24 58 62 45 58 52 85];
X = [4890 6180 3730 2930 7600 5580 4570 5230 4470 3420 3460 5360 ...
     4470 4470 3320 4910 5010 6630 5710 5130 5330 5010 3660 3340 ...
     3600 5560 5760 6440 6310 6300];
n = numel(T);

NBOOT = 2000;       % replicates for the CvM bootstrap p-value
NSIM  = 5000;       % replicates for the lower-tail comparison
SEED  = 20261015;

% ------------------------------------------------ PIT pseudo-observations
u = avg_rank(T)' / (n + 1);
v = avg_rank(X)' / (n + 1);

% ------------------------------------------------ MLE of the two copulas
gridF = [linspace(-30, -0.05, 300), linspace(0.05, 30, 300)];
gridC = linspace(0.01, 30, 400);
[thF, llF] = cop_mle(@frank_c,   u, v, gridF, [-30 30]);
[thC, llC] = cop_mle(@clayton_c, u, v, gridC, [0.01 30]);

% ------------------------------------------------ Table 13
rng(SEED, 'twister');
[cvmF, pF] = cop_gof(u, v, @frank_c,   @frank_Cv,   @frank_sample,   thF, [-30 30],   NBOOT);
[cvmC, pC] = cop_gof(u, v, @clayton_c, @clayton_Cv, @clayton_sample, thC, [0.01 30], NBOOT);

fprintf('Table 13  Goodness-of-fit test of the Frank and Clayton copulas ');
fprintf('for T and X\n\n');
fprintf('%-8s %10s %11s %11s %9s %14s\n', 'Model', 'logLik', 'AIC', 'BIC', 'CvM', 'p_bootstrap');
fprintf('%-8s %10.4f %11.4f %11.4f %9.4f %14.4f\n', 'Clayton', llC, ...
        2 - 2*llC, log(n) - 2*llC, cvmC, pC);
fprintf('%-8s %10.4f %11.4f %11.4f %9.4f %14.4f\n', 'Frank', llF, ...
        2 - 2*llF, log(n) - 2*llF, cvmF, pF);
fprintf(['(MLE: Clayton theta = %.4f, Frank theta = %.4f; p-values from %d ', ...
         'parametric-bootstrap replicates)\n\n'], thC, thF, NBOOT);

% ------------------------------------------------ Table 14
QS = [0.30 0.20 0.15 0.10];
nq = numel(QS);
lam_obs = zeros(1, nq);
for j = 1:nq
    lam_obs(j) = lamhat(u, v, QS(j));
end

rng(SEED + 21, 'twister');
nullF = zeros(NSIM, nq);
for i = 1:NSIM
    [su, sv] = frank_sample(thF, n);
    for j = 1:nq
        nullF(i, j) = lamhat(su, sv, QS(j));
    end
end

rng(SEED + 22, 'twister');
nullC = zeros(NSIM, nq);
for i = 1:NSIM
    [su, sv] = clayton_sample(thC, n);
    for j = 1:nq
        nullC(i, j) = lamhat(su, sv, QS(j));
    end
end

fprintf('Table 14  Lower-tail agreement of the two copulas\n\n');
fprintf('%8s %10s %12s %14s %18s %20s\n', 'q', 'lam_hat', ...
        'p_GOF^Frank', 'p_GOF^Clayton', 'Median(lam) Frank', 'Median(lam) Clayton');
for j = 1:nq
    pf = (sum(nullF(:, j) >= lam_obs(j)) + 1) / (NSIM + 1);
    pc = (sum(nullC(:, j) >= lam_obs(j)) + 1) / (NSIM + 1);
    fprintf('%8.4f %10.4f %12.4f %14.4f %18.4f %20.4f\n', QS(j), ...
            lam_obs(j), pf, pc, median(nullF(:, j)), median(nullC(:, j)));
end
fprintf(['(lam(q) = C_n(q,q)/q; p-values and medians from %d replicates of ', ...
         'each fitted copula)\n\n'], NSIM);

% ------------------------------------------------ CSV output
fid = fopen('Table13_copula_GOF.csv', 'w');
fprintf(fid, 'Model,logLik,AIC,BIC,CvM,p_bootstrap\n');
fprintf(fid, 'Clayton,%.4f,%.4f,%.4f,%.4f,%.4f\n', llC, 2 - 2*llC, ...
        log(n) - 2*llC, cvmC, pC);
fprintf(fid, 'Frank,%.4f,%.4f,%.4f,%.4f,%.4f\n', llF, 2 - 2*llF, ...
        log(n) - 2*llF, cvmF, pF);
fclose(fid);

fid = fopen('Table14_tail_dependence.csv', 'w');
fprintf(fid, 'q,lambda_hat,p_GOF_Frank,p_GOF_Clayton,median_lambda_Frank,median_lambda_Clayton\n');
for j = 1:nq
    pf = (sum(nullF(:, j) >= lam_obs(j)) + 1) / (NSIM + 1);
    pc = (sum(nullC(:, j) >= lam_obs(j)) + 1) / (NSIM + 1);
    fprintf(fid, '%.4f,%.4f,%.4f,%.4f,%.4f,%.4f\n', QS(j), lam_obs(j), ...
            pf, pc, median(nullF(:, j)), median(nullC(:, j)));
end
fclose(fid);
fprintf('written: Table13_copula_GOF.csv, Table14_tail_dependence.csv\n');
end

% ===========================================================================
%                                   copulas
% ===========================================================================
function y = frank_c(u, v, th)
A = (exp(-th.*u) - 1) .* (exp(-th.*v) - 1);
D = exp(-th) - 1;
y = (-th) .* D .* exp(-th.*(u + v)) ./ (D + A).^2;
end

function y = frank_Cv(u, v, th)
A = (exp(-th.*u) - 1) .* (exp(-th.*v) - 1);
D = exp(-th) - 1;
y = exp(-th.*u) .* (exp(-th.*v) - 1) ./ (D + A);
end

function [uu, vv] = frank_sample(th, m)
uu = rand(m, 1); w = rand(m, 1);
D = exp(-th) - 1;
B = w .* D ./ (exp(-th.*uu) - w .* (exp(-th.*uu) - 1));
vv = -log1p(B) / th;
end

function y = clayton_c(u, v, th)
y = ((1 + th) .* (u.*v).^(-th - 1) ...
     .* (u.^(-th) + v.^(-th) - 1).^(-2 - 1./th));
end

function y = clayton_Cv(u, v, th)
S = u.^(-th) + v.^(-th) - 1;
y = u.^(-th - 1) .* S.^(-1./th - 1);
end

function [uu, vv] = clayton_sample(th, m)
uu = rand(m, 1); w = rand(m, 1);
vv = (1 + (w.^(-th./(1 + th)) - 1) .* uu.^(-th)).^(-1./th);
end

% ===========================================================================
%                            estimation and testing
% ===========================================================================
function f = negll(cfun, u, v, th, thMin)
if abs(th) < thMin, f = 1e12; return; end
d = cfun(u, v, th);
if any(~isfinite(d)) || any(d <= 0), f = 1e12; return; end
f = -sum(log(d));
end

function [th, logL] = cop_mle(cfun, u, v, grid, bnd)
nll = @(t) negll(cfun, u, v, t, 1e-9);
vals = zeros(size(grid));
for i = 1:numel(grid), vals(i) = nll(grid(i)); end
[~, i0] = min(vals);
t0 = grid(i0);
span = grid(2) - grid(1);
o = optimset('TolX', 1e-10, 'TolFun', 1e-12, 'Display', 'off');
r1 = fminbnd(nll, max(bnd(1), t0 - 3*span), min(bnd(2), t0 + 3*span), o);
r2 = fminbnd(nll, bnd(1), bnd(2), o);
if nll(r1) <= nll(r2), th = r1; else, th = r2; end
logL = -nll(th);
end

function th = cop_mle_fast(cfun, u, v, bnd)
nll = @(t) negll(cfun, u, v, t, 1e-9);
o = optimset('TolX', 1e-8, 'TolFun', 1e-10, 'Display', 'off');
th = fminbnd(nll, bnd(1), bnd(2), o);
end

function S = rosen_cvm(u, v, Cvfun, th)
e1 = min(max(u, 0), 1);
e2 = min(max(Cvfun(u, v, th), 0), 1);
m = numel(e1);
A = bsxfun(@min, 1 - e1(:), (1 - e1(:))') .* ...
    bsxfun(@min, 1 - e2(:), (1 - e2(:))');
S = sum(A(:))/m - sum((1 - e1(:).^2) .* (1 - e2(:).^2))/2 + m/9;
end

function [cvm, p] = cop_gof(u, v, cfun, Cvfun, samplefun, th, bnd, NBOOT)
cvm = rosen_cvm(u, v, Cvfun, th);
cnt = 0; m = numel(u);
for b = 1:NBOOT
    [su, sv] = samplefun(th, m);
    thb = cop_mle_fast(cfun, su, sv, bnd);
    if rosen_cvm(su, sv, Cvfun, thb) >= cvm, cnt = cnt + 1; end
end
p = (cnt + 1) / (NBOOT + 1);
end

function r = avg_rank(x)
x = x(:); m = numel(x);
[s, i] = sort(x);
r = zeros(m, 1); r(i) = (1:m)';
j = 1;
while j <= m
    k = j;
    while k < m && s(k+1) == s(j), k = k + 1; end
    if k > j, r(i(j:k)) = mean(j:k); end
    j = k + 1;
end
end

function lam = lamhat(u, v, q)
lam = mean(u <= q & v <= q) / q;
end
