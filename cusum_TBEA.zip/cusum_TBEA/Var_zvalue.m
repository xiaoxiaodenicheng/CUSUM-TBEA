integrand = @(z)(z.*pdfZ(8, 7, z, 1, 10, 1, 1, 10, 1, 0.5, 10, 10));
Ez = integral(integrand, eps, 10);
fprintf('Ez = %.5f\n', Ez);

integrand_var = @(z) (z.^2 .* pdfZ(8, 7, z, 1, 10, 1, 1, 10, 1, 0.8, 10, 10));
Ez2 = integral(integrand_var, eps, 10);

% 计算方差 Var(Z) = E[Z^2] - (E[Z])^2
VarZ = Ez2 - Ez^2;

% 计算标准差 Std(Z) = sqrt(Var(Z))
StdZ = sqrt(VarZ);

% 输出结果
fprintf('Ez  = %.5f\n', Ez);
fprintf('Ez2 = %.5f\n', Ez2);
fprintf('VarZ = %.5f\n', VarZ);
fprintf('StdZ = %.5f\n', StdZ);


% C = 8;            % Copula类型: 
                    % 8=Clayton ;  9=franck ; 10=gumbel

% ZZ = 7;           % 联合监控统计量Z的计算方式:
                    % 5: Z = X1 - T1 ;  6: Z = X1 ./ T1 ;  7:Z = X1 + (1 ./ T1)
                    
% UCL = 1.5;        % 需要计算的 PDF 位置


% disX = 1;         % X 的分布类型
                    % 1=Gamma  2=Lognormal  3=Normal  4=Weibull分布
% muX0 = 10;        % X 的均值
% sdX0 = 1;         % X 的标准差

% disT = 1;         % T 的分布类型
% muT0 = 10;        % T 的均值
% sdT0 = 1;         % T 的标准差

% tau = 0.2;        % 相关性参数
% muX1 = 10;        % 变换参数
% muT1 = 10;        % 变换参数



% 2.01023
% 4.05510
% 0.01406
% 0.11857 

%Ez = 0.04640
%Ez  = 0.04640
%Ez2 = 0.00698
%VarZ = 0.00482
%StdZ = 0.06945