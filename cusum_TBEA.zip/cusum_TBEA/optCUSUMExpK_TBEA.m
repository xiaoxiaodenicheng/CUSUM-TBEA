%function [UCLc,ARL0,flag]=optCUSUMExpK(K,rho,arl0,lb,ub)
%------通过二分法优化 CUSUM 控制限UCL，使得 CUSUM 控制图的平均运行长度（ARL）接近目标值 arl0。

function [UCLc,ARL0,flag]=optCUSUMExpK_TBEA(K,arl0,lb,ub)
flag=0; 
while true

    % ARL函数参数赋值
    UCL=(lb+ub)/2;
    rho1=1;
    rho2=1;
    %muX0=10;
    %muT0=10;
    muX0=4946;
    muT0=58.9;

    %ARL=rlU_cusum_tbeaCSgg(K, UCL, rho1, rho2, muX0, muT0);
    %ARL=rlU_cusum_tbeaCSng(K, UCL, rho1, rho2, muX0, muT0);
    %ARL=rlU_cusum_tbeaFSng(K, UCL, rho1, rho2, muX0, muT0);
    %ARL=rlU_cusum_tbeaFSgg(K, UCL, rho1, rho2, muX0, muT0);
    ARL=rlU_cusum_tbeaFSwg(K, UCL, rho1, rho2, muX0, muT0);
    %ARL=rlU_cusum_tbeaCSgw(K, UCL, rho1, rho2, muX0, muT0);
    %ARL=rlU_cusum_tbeaFSgw(K, UCL, rho1, rho2, muX0, muT0);
    %ARL=rlU_cusum_tbeaCSnw(K, UCL, rho1, rho2, muX0, muT0);
    %ARL=rlU_cusum_tbeaFSnw(K, UCL, rho1, rho2, muX0, muT0);
    %ARL=rlU_cusum_tbeaCSww(K, UCL, rho1, rho2, muX0, muT0);
    %ARL=rlU_cusum_tbeaFSww(K, UCL, rho1, rho2, muX0, muT0);
    
    %if ARL<arl0+1 && ARL>arl0-1
    if ARL<arl0+0.1 && ARL>arl0-0.1
        UCLc=UCL;
        ARL0=ARL;
        break; 
    elseif ARL<=arl0-0.1
     lb=UCL;
    else
     ub=UCL;
    end
    flag=flag+1;
    if flag>40
        UCLc=UCL;
        ARL0=ARL;
        break;
    end
end
disp(['UCL = ', num2str(UCLc)]);
end 
