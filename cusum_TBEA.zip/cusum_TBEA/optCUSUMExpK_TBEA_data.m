K= 0.15;
arl0 = 200;
lb = 1;  
%ub = 0.3183;shewhart
ub = 1.5;
rho1 = 1;
rho2 = 1;
%muX0=10;
%muT0=10;
%muX0=5001.1;
%muT0=61.1;
muX0=4946;
muT0=58.9;

[UCLc,ARL0,flag]=optCUSUMExpK_TBEA(K,arl0,lb,ub);
% 输出结果
fprintf('UCLc = %.5f\n', UCLc);
fprintf('ARL0 = %.5f\n', ARL0);
fprintf('flag = %.5f\n', flag);


