%% =====================================================================
%  Scatter_X_T.m
%  Figure 1 of the manuscript: scatter plot of the maintenance cost X
%  against the time interval T between two consecutive breakdowns.
%
%  Data source: Table 11 of the manuscript
%      Phase I  (n = 30, 10/03/12 - 09/11/16) -> solid filled circles
%      Phase II (n = 14, 11/01/17 - 27/12/18) -> open    circles
%  (the Phase I / Phase II marker assignment was verified pixel-wise
%   against the published figure: 30/30 Phase I points are solid,
%   12/14 Phase II points are open, the remaining 2 are overlapped by
%   a Phase I marker drawn at the same position)
%
%  Style reproduced from the published figure:
%      * horizontal axis = T (days), 0-100, step 10;
%        vertical axis = X (euros), 0-9000, step 1000;
%      * light gray grid lines (RGB 233/233/233); only the left and the
%        bottom axis frame are drawn (no top / right border, no tick
%        marks on those two sides), tick marks pointing inwards;
%      * black markers, no connecting lines, no title, no legend;
%      * Times New Roman throughout; T and X in italic (SCI convention);
%      * vector (SVG) output so the figure stays editable.
%
%  ---------------------------------------------------------------------
%  IMPORTANT NOTE ON THE "plot" NAME
%  This folder contains a file named  plot.m  (a script).  MATLAB gives
%  the current folder priority over its built-in functions, so any call
%  to  plot(...)  inside this folder resolves to that script and fails
%  with "Unsupported attempt to execute script plot as a function".
%  To stay immune to that name clash, this script draws the markers
%  with the low-level  line()  command instead of  plot().
%  (Permanent fix: rename plot.m to e.g. plot_相关性.m / fig_scatter_XT.m)
%  ---------------------------------------------------------------------
%
%  Backward compatible with MATLAB < R2014b:
%      - no yline / readmatrix / exportgraphics / MarkerEdgeWidth;
%      - axis limits and ticks use the 'XLim'/'XTick' properties rather
%        than xlim/xticks/ylim/yticks (R2016b+);
%      - SVG export through print('-dsvg', ...) with a saveas fallback;
%      - the SVG font fix-up is done in plain MATLAB (no external tools).
%% =====================================================================
clc;
clear;
close all;

%% ---------------- 1. original data (Table 11) --------------------------
% Phase I: 30 failure events
T1 = [62; 79; 58; 33; 85; 92; 69; 67; 43; 41; ...
      55; 78; 56; 53; 41; 81; 32; 70; 82; 51; ...
      57; 47; 51; 24; 58; 62; 45; 58; 52; 85];

X1 = [4890; 6180; 3730; 2930; 7600; 5580; 4570; 5230; ...
      4470; 3420; 3460; 5360; 4470; 4470; 3320; 4910; ...
      5010; 6630; 5710; 5130; 5330; 5010; 3660; 3340; 3600; ...
      5560; 5760; 6440; 6310; 6300];

% Phase II: 14 failure events
T2 = [63; 69; 47; 69; 91; 45; 70; 54; 23; 44; 56; 68; 26; 33];

X2 = [5080; 5350; 3770; 4590; 5940; 5420; 4580; 5430; ...
      5740; 6110; 7340; 8160; 4800; 6570];

n1 = numel(T1);
n2 = numel(T2);

%% ---------------- 2. style constants ------------------------------------
FONT_NAME  = 'Times New Roman';
FS_TICK    = 11;                    % tick label font size
FS_LABEL   = 13;                    % axis label font size
C_MARKER   = [0 0 0];               % markers: black
C_GRID     = [233 233 233]/255;     % light gray grid lines (sampled from the figure)
C_AXIS     = [0 0 0];               % axis lines: black
MSIZE      = 6;                     % marker size
LWD        = 0.8;                   % marker edge width

%% ---------------- 3. figure and axes ------------------------------------
fig = figure('Color', 'w', ...
             'Units', 'centimeters', ...
             'Position', [5, 5, 12.4, 9.3], ...
             'Renderer', 'painters');

ax = axes('Parent', fig);
hold(ax, 'on');

% Only the left and the bottom axis frame are drawn: no top and no
% right border, and no tick marks on those two sides.  This matches the
% published figure, where the top and the right edge show nothing but
% the light gray grid lines.
box(ax, 'off');
set_prop(ax, 'XAxisLocation', 'bottom');
set_prop(ax, 'YAxisLocation', 'left');

% --- Phase I: solid filled circles ---------------------------------------
% NOTE: line() is used on purpose, see the header note about plot.m.
% 'builtin' is used as a final safeguard in case a file named line.m is
% ever added to this folder as well; on very old releases (no 'builtin')
% the plain call is used instead.
if exist('builtin', 'builtin') == 5
    builtin('line', ax, T1, X1, ...
         'LineStyle', 'none', ...
         'Marker', 'o', ...
         'MarkerSize', MSIZE, ...
         'MarkerFaceColor', C_MARKER, ...
         'MarkerEdgeColor', C_MARKER, ...
         'LineWidth', LWD);
else
    line(ax, T1, X1, ...
         'LineStyle', 'none', ...
         'Marker', 'o', ...
         'MarkerSize', MSIZE, ...
         'MarkerFaceColor', C_MARKER, ...
         'MarkerEdgeColor', C_MARKER, ...
         'LineWidth', LWD);
end

% --- Phase II: open circles ----------------------------------------------
if exist('builtin', 'builtin') == 5
    builtin('line', ax, T2, X2, ...
         'LineStyle', 'none', ...
         'Marker', 'o', ...
         'MarkerSize', MSIZE, ...
         'MarkerFaceColor', 'none', ...
         'MarkerEdgeColor', C_MARKER, ...
         'LineWidth', LWD);
else
    line(ax, T2, X2, ...
         'LineStyle', 'none', ...
         'Marker', 'o', ...
         'MarkerSize', MSIZE, ...
         'MarkerFaceColor', 'none', ...
         'MarkerEdgeColor', C_MARKER, ...
         'LineWidth', LWD);
end

%% ---------------- 4. axis formatting -------------------------------------
% axis limits and tick locations (property form -> works on old MATLAB)
set(ax, 'XLim', [0 100],   'YLim', [0 9000], ...
         'XTick', 0:10:100, 'YTick', 0:1000:9000);

% axis labels: variables in italic, upright ticks (journal convention)
%
% NOTE on the italic setting: xlabel/ylabel only accept a fixed set of
% name-value pairs (FontSize, FontWeight, FontName, Color, Rotation,
% Interpreter).  'FontStyle' is NOT among them, and recent releases
% (R2025b) reject it with
%     "The property FontStyle cannot be recognized for the class Text".
% The label is therefore created first and the italic style is applied
% afterwards through the returned text handle, which accepts the full
% set of Text properties.
hXl = xlabel(ax, 'T', ...
       'Interpreter', 'tex', ...
       'FontName', FONT_NAME, ...
       'FontSize', FS_LABEL);
hYl = ylabel(ax, 'X', ...
       'Interpreter', 'tex', ...
       'FontName', FONT_NAME, ...
       'FontSize', FS_LABEL);

set_italic(hXl);
set_italic(hYl);

% ticks, line widths and grid.
% Each property is applied one by one: a few of them (GridAlpha, Layer)
% only exist from R2014b on, and a single unknown property would
% otherwise abort the whole script on an older release.
set_prop(ax, 'FontName',  FONT_NAME);
set_prop(ax, 'FontSize',  FS_TICK);
set_prop(ax, 'LineWidth', 0.8);
set_prop(ax, 'XMinorTick','off');
set_prop(ax, 'YMinorTick','off');
set_prop(ax, 'XColor',    C_AXIS);
set_prop(ax, 'YColor',    C_AXIS);
set_prop(ax, 'Layer',     'top');

% Tick marks point inwards (as in the published figure, where the marks
% sit inside the axes next to the left and bottom frame).  The top and
% the right side carry no frame and no tick marks at all, because
% 'box off' is used above.
set_prop(ax, 'TickDir', 'in');
if isprop(ax, 'XAxis')
    set_prop(ax.XAxis, 'TickDirection', 'in');
end
if isprop(ax, 'YAxis')
    set_prop(ax.YAxis, 'TickDirection', 'in');
end

% light gray grid, drawn behind the markers
set_prop(ax, 'XGrid',     'on');
set_prop(ax, 'YGrid',     'on');
set_prop(ax, 'GridColor', C_GRID);
set_prop(ax, 'GridAlpha', 1);
set_prop(ax, 'Layer',     'bottom');

%% ---------------- 5. export as SVG --------------------------------------
outDir = fileparts(mfilename('fullpath'));
if isempty(outDir)
    outDir = pwd;
end
svgName = fullfile(outDir, 'Scatter_X_T.svg');
pngName = fullfile(outDir, 'Scatter_X_T.png');

export_svg(fig, svgName);
fix_svg_font(svgName, FONT_NAME);
export_png(fig, pngName);

fprintf('Phase I observations : %d\n', n1);
fprintf('Phase II observations: %d\n', n2);
fprintf('SVG figure exported successfully: %s\n', svgName);
fprintf('PNG preview exported        : %s\n', pngName);

%% =====================================================================
%  local helper functions
%% =====================================================================
function set_prop(h, prop, value)
% SET_PROP  Set one graphics property, ignoring it if the running
%   MATLAB release does not know that property.
%
%   Several axes properties (GridAlpha, Layer, ...) were introduced in
%   R2014b.  On an older release a single unknown property would abort
%   the whole script, so every cosmetic property is applied through
%   this guarded wrapper.
    try
        set(h, prop, value);
    catch
        % property not supported by this release -> ignore
    end
end

function set_italic(h)
% SET_ITALIC  Make a text object italic, across MATLAB releases.
%
%   R2014b and later use the FontStyle property; older releases only
%   provide FontAngle.  Both are tried so the same script works
%   everywhere.  Errors are swallowed on purpose: an italic label is a
%   cosmetic detail and must never abort the figure generation.
    if isempty(h) || ~ishandle(h)
        return;
    end
    try
        set(h, 'FontStyle', 'italic');
        return;
    catch
        % FontStyle not available -> fall through to FontAngle
    end
    try
        set(h, 'FontAngle', 'italic');
    catch
        % no italic support at all: keep the upright label
    end
end

function export_svg(fig, fname)
% Export the figure to SVG (vector); falls back to saveas on old releases.
    try
        print(fig, '-dsvg', '-painters', fname);
    catch
        try
            saveas(fig, fname);
        catch err
            warning('SVG export failed: %s', err.message);
        end
    end
end

function export_png(fig, fname)
% Export a 600-dpi PNG preview (many journals ask for it next to the vector file).
    try
        print(fig, '-dpng', '-r600', fname);
    catch
        try
            print(fig, '-dpng', fname);
        catch err
            warning('PNG export failed: %s', err.message);
        end
    end
end

function fix_svg_font(fname, fontName)
% FIX_SVG_FONT  Force the font family of every text element in the SVG.
%
%   On macOS, MATLAB's print('-dsvg', ...) writes the generic system UI
%   font name  ".AppleSystemUIFont"  into the SVG instead of the font
%   actually requested (e.g. "Times New Roman").  Journals that check
%   the font of the submitted figure would then see a system font, and
%   the text would be re-rendered with a substitute on the reviewer's
%   machine.  This routine rewrites the font-family attribute of every
%   <g> / <text> element so the file really carries the intended font.
%
%   Written in plain MATLAB (no external tools) so it also runs on
%   MATLAB < R2014b.
    if exist(fname, 'file') ~= 2
        return;
    end

    fid = fopen(fname, 'r');
    if fid < 0
        return;
    end
    txt = fread(fid, inf, 'uint8=>char')';
    fclose(fid);

    % 1) generic system-font names produced by MATLAB on macOS
    generic = {'.AppleSystemUIFont', '.AppleSystemUIFont-Semibold', ...
               'Helvetica', 'Arial', 'DejaVu Sans'};

    for i = 1:numel(generic)
        txt = strrep(txt, ['font-family="' generic{i} '"'], ...
                            ['font-family="' fontName '"']);
    end

    % 2) any other font-family that is not the requested one
    %    (e.g. a fallback name MATLAB picked for the italic axis labels)
    [tok, ~] = regexp(txt, 'font-family="([^"]*)"', 'tokens');
    if ~isempty(tok)
        for i = 1:numel(tok)
            if ~strcmp(tok{i}{1}, fontName)
                txt = strrep(txt, ['font-family="' tok{i}{1} '"'], ...
                                    ['font-family="' fontName '"']);
            end
        end
    end

    fid = fopen(fname, 'w');
    if fid < 0
        return;
    end
    fwrite(fid, txt, 'char');
    fclose(fid);
end
