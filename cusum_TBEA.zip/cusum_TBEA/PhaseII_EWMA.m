
% ============================================
% 从 Excel 读取数据并绘制 SCI 风格的单侧 EWMA 控制图
% 图形风格与 CUSUM_Control_Chart2.svg 保持一致
% E_t^+ = max[Z0, lambda*Z_t + (1-lambda)*E_{t-1}^+]
% ============================================

clc;
clear;
close all;

%% 1. 从 Excel 读取数据
filename = 'REALDATA.xlsx';
data = readmatrix(filename);

% 转换为列向量，并去除缺失值
data = data(:);
data = data(~isnan(data));
n = length(data);

if n < 2
    error('数据量太少，请至少提供两个有效观测值。');
end

%% 2. 参数设置
lambda = 0.7;      % EWMA 平滑系数

%Z0 = 0.08082;
%Z0 = 1.03278;   % 估计初始均值
Z0 = 2.08818;

%H = 0.3811;        % 控制限
%H = 1.5609;
H = 2.6168;



%% 3. 计算单侧 EWMA 统计量
% 保留原始 EWMA 计算逻辑
E = zeros(n, 1);
E(1) = Z0;

for t = 2:n
    ewma_core = lambda * data(t) + (1 - lambda) * E(t-1);
    base_term = Z0;
    E(t) = max(base_term, ewma_core);
end

%% 4. SCI 论文风格参数设置
% 与 CUSUM 图保持一致
blue = [0.00, 0.40, 0.85];     % 蓝色数据线
red = [1.00, 0.20, 0.20];      % 红色控制限
axisColor = [0.25, 0.25, 0.25];

% 字体
fontName = 'Times New Roman';
fontSize = 10;

% 线宽与标记尺寸
dataLineWidth = 1.1;
controlLineWidth = 1.1;
axisLineWidth = 0.8;
markerSize = 4.5;

%% 5. 创建图形
figure('Name', 'EWMA Control Chart', ...
       'NumberTitle', 'off', ...
       'Color', 'white', ...
       'Units', 'centimeters', ...
       'Position', [5, 5, 12.5, 8.5]);

ax = axes;
hold(ax, 'on');
box(ax, 'off');

% 数据序列：蓝色细线 + 空心圆
plot(1:n, E, '-o', ...
    'Color', blue, ...
    'LineWidth', dataLineWidth, ...
    'Marker', 'o', ...
    'MarkerSize', markerSize, ...
    'MarkerEdgeColor', blue, ...
    'MarkerFaceColor', 'white');

%% 6. 绘制上控制限
yline(H, '--', ...
    'Color', red, ...
    'LineWidth', controlLineWidth, ...
    'HandleVisibility', 'off');

%% 7. 坐标轴设置
% 横坐标范围
xlim([0, n + 1]);

% 横坐标刻度：与 CUSUM 代码保持一致
if n <= 15
    xticks(0:1:n);
else
    xticks(0:5:ceil(n/5)*5);
end

% 纵坐标上限：同时考虑统计量最大值与控制限
yMaxData = max([E; H]);

if yMaxData <= 0
    yUpper = 1;
else
    yUpper = 0.1 * ceil(1.15 * yMaxData / 0.1);
end

ylim([0, yUpper]);

% 与 CUSUM 代码相同的纵坐标刻度规则
if yUpper <= 1
    yStep = 0.3;
elseif yUpper <= 2
    yStep = 0.05;
else
    yStep = 0.3;
end

yticks(0:yStep:yUpper);

% 坐标轴外观
set(ax, ...
    'FontName', fontName, ...
    'FontSize', fontSize, ...
    'FontWeight', 'normal', ...
    'LineWidth', axisLineWidth, ...
    'XColor', axisColor, ...
    'YColor', axisColor, ...
    'TickDir', 'out', ...
    'TickLength', [0.015, 0.015], ...
    'XMinorTick', 'off', ...
    'YMinorTick', 'off', ...
    'Layer', 'top');

% 不显示网格
grid(ax, 'off');

%% 8. 坐标轴标签：数学公式格式
xlabel('$t$', ...
    'Interpreter', 'latex', ...
    'FontName', fontName, ...
    'FontSize', 11);

ylabel('$E_t^+$', ...
    'Interpreter', 'latex', ...
    'FontName', fontName, ...
    'FontSize', 11);

%% 9. 在控制限右侧标注数值
text(n + 0.8, H + 0.035 * yUpper, ...
    sprintf('$H_3 = %.5f$', H), ...
    'Interpreter', 'latex', ...
    'FontName', fontName, ...
    'FontSize', 9, ...
    'HorizontalAlignment', 'right', ...
    'VerticalAlignment', 'bottom', ...
    'Color', [0.15, 0.15, 0.15], ...
    'Clipping', 'off');

%% 10. 标记超出控制限的观测点
out_of_control = find(E > H);

if ~isempty(out_of_control)
    plot(out_of_control, E(out_of_control), 'o', ...
        'MarkerSize', markerSize + 0.5, ...
        'MarkerEdgeColor', red, ...
        'MarkerFaceColor', 'white', ...
        'LineWidth', 1.1, ...
        'HandleVisibility', 'off');
end

%% 11. 导出 SVG 矢量图
set(gcf, 'InvertHardcopy', 'off');

exportgraphics(gcf, 'EWMA_Control_Chart3.svg', ...
    'ContentType', 'vector');

fprintf('EWMA 控制图已生成并导出为 SVG 矢量图。\n');
fprintf('样本量：%d\n', n);
fprintf('EWMA 平滑系数 lambda = %.2f\n', lambda);
fprintf('上控制限 H = %.4f\n', H);
fprintf('超出控制限的观测点数量：%d\n', ...
    numel(out_of_control));
